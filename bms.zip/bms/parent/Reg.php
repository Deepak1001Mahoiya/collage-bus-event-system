<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Registration Form</title>
</head>
<script language="javascript" type="text/javascript" src="valid.js">
</script>
<body>
<?php
	include('headerl.php');
?>
<form action="addst.php" method="post">
<center>
<table width="498" border="0">
  <caption>Student Registration Form</caption>
  <tr>
    <td width="261">Roll Number</td>
    <td width="227"><input type="text" name="rn" id="tf" required="required" onchange="vrno()"/><p id="vcnm"></p></td>
  </tr>
  <tr>
    <td>Name</td>
    <td><input type="text" name="nm" id="textfield2" required="required" /></td>
  </tr>
  <tr>
    <td>Contact</td>
    <td><input type="text" name="cnt" id="tf3" required="required" onchange="isnum()"/><p id="vnm"></p></td>
  </tr>
  <tr>
    <td>Address</td>
    <td><label for="textarea"></label>
      <textarea name="add" id="textarea" cols="35" rows=""></textarea></td>
  </tr>
  
  <tr>
    <td>Pick Up Location</td>
    <td><input type="text" name="pul" id="textfield4" required="required" /></td>
  </tr>
  <tr>
    <td>Password</td>
    <td><input type="text" name="pass" id="textfield5" required="required" /></td>
  </tr>
  <tr>
    <td align="right"><input type="Submit" name="button" value='Register'></td>
    <td><input type="button" value="Cancel"onclick="javascript:window.location='Login.php'"></td>
  </tr>
</table>
<label for="textfield"></label>
</center>
</form>
</body>
</html>