<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Today's Tracking</title>
</head>

<body>
<?php
error_reporting(0);
include_once('connection.php');
session_start();
$r=$_SESSION['user'];
$conn = mysqli_query ($conn, "SELECT driver.D_name, driver.Contact, student.Pick_up_location, bus.RTO_no 
FROM driver, student, bus 
WHERE driver.D_no AND student.S_id=$r[0] AND bus.B_no");

?>
<table width="100%" border="20">
  <tr>
  	<td width="15%">Driver Name</td>
    <td width="15%">Contact</td>
    <td width="15%"> Pick Up point</td>
    <td width="15%">Bus Number </td>
    
  </tr>
  <tr>
    <td><?php echo $row['D_name']; ?>
    <td><?php echo $row['Contact']; ?></td>
    <td><?php echo $row['Pick_up_location']; ?></td>
    <td><?php echo $row['RTO_no']; ?></td>
    
  </tr>
</table>

</body>
</html>