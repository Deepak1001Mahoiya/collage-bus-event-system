<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>
<!-- <script>
function verify()
{
	var nm=document.getElementById("tf").value;
	if(nm.length>10)
	{
		document.getElementById("msg").innerHTML="Number Must Be in<br>MP 12 QB9766<br> this Format only"+nm;
		document.getElementById("tf").value=null;
	}	
	else
	{
		document.getElementById("msg").innerHTML=" ";	
	}
}
</script> -->
<body>
<?php
include('header.php');
?>
<center>

<form name="addbus" method="post"  enctype="multipart/form-data" action="addb.php">
<!-- <input type="text" name="" placeholder="" required="required"> -->
<input type="text" name="nm" placeholder="BUS NUMBER" aria-label="RTO no" aria-describedby="basic-addon1">
<!-- <p id="msg"></p> -->
<input type="submit" name="button" value="submit">
<button onclick="javascript:window.location='home.php'">Cancel</button>
</form>
</center>
</body>
</html>