<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>

<body>
<?php
include('header.php');
include('connection.php');
// $sql =("select  from  where ");
$conn =  mysqli_query($conn, "select * from student");

?>
<center>
<table border="2" class="table table-bordered border-primary" style= "background-color: #84ed86; color: #761a9b; margin: 0 auto;">
<tr>
<th>Student Id</th>
<th>Roll Number</th>
<th>Student Name</th>
<th>Contact</th>
<th>Address</th>
<th>Pick Up Location</th>
<th>Delete/Suspend</th>
</tr>
<?php 
 while($row=  mysqli_fetch_array($conn))
{
?>
<tr align="center">
                <td><?php echo $row['S_id']; ?></td>
                <td><?php echo $row['Roll_no']; ?></td>
                <td><?php echo $row['S_name']; ?></td>
                <td><?php echo $row['Contact']; ?></td>
                <td><?php echo $row['Address'] ;?></td>
                <td><?php echo $row['Pick_up_location'] ;?></td>
                <td><a href="dels.php?id=<?php echo $row[0];?>">Delete</a></td>
</tr>
<?php } 
?>
</table>
</center>

</body>
</html>