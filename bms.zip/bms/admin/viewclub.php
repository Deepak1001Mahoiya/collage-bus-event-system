<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title>Untitled Document</title>
</head>

<body>
    <?php

    include('header.php');
    include_once('connection.php');



    $query = "SELECT C_name FROM club ";
    $result = $conn->query($query);
    if ($result->num_rows > 0) {
        $options = mysqli_fetch_all($result, MYSQLI_ASSOC);
    }
    ?>
    <select name="C_name">
        <option>Select Route</option>
        <?php
        foreach ($options as $option) {
        ?>
            <option><?php echo $option['C_name']; ?> </option>
        <?php
        }
        ?>
    </select>
        <input type="submit" value="View">
    </form>
</body>

</html>